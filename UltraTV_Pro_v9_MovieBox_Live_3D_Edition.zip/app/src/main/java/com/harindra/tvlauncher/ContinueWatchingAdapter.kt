package com.harindra.tvlauncher

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ContinueWatchingAdapter(
    private val prefs: PrefsManager,
    private val onItemClick: (ContinueWatchingItem) -> Unit
) : RecyclerView.Adapter<ContinueWatchingAdapter.CwViewHolder>() {

    private val items = mutableListOf<ContinueWatchingItem>()

    fun submitList(newItems: List<ContinueWatchingItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CwViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_continue_card, parent, false)
        return CwViewHolder(view)
    }

    override fun onBindViewHolder(holder: CwViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class CwViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivThumb: ImageView = itemView.findViewById(R.id.ivCwThumb)
        private val tvSource: TextView = itemView.findViewById(R.id.tvCwSourceBadge)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvCwTitle)
        private val tvSub: TextView = itemView.findViewById(R.id.tvCwSubtitle)
        private val vProgress: View = itemView.findViewById(R.id.vCwProgress)

        fun bind(item: ContinueWatchingItem) {
            tvTitle.text = item.title
            tvSub.text = item.subtitle
            tvSource.text = item.sourceLabel

            val isYt = item.type == ContinueWatchingItem.TYPE_YOUTUBE || item.type == ContinueWatchingItem.TYPE_YOUTUBE_SEARCH
            val isMb = item.type == ContinueWatchingItem.TYPE_MOVIEBOX
            tvSource.setBackgroundResource(when { isMb -> R.drawable.bg_badge_moviebox; isYt -> R.drawable.bg_badge_yt; else -> R.drawable.bg_badge_iptv })
            vProgress.setBackgroundColor(when { isMb -> Color.parseColor("#F59E0B"); isYt -> Color.parseColor("#EF4444"); else -> Color.parseColor("#38BDF8") })

            val density = itemView.resources.displayMetrics.density
            val totalW = (224f * density).toInt()
            val lp = vProgress.layoutParams
            lp.width = (totalW * item.progressPercent.coerceIn(10, 98) / 100)
            vProgress.layoutParams = lp

            MediaImageLoader.loadRemoteImage(item.thumbUrl, ivThumb, item.fallbackResId, 440)

            itemView.setOnClickListener { onItemClick(item) }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.10f)
            }
        }
    }
}
