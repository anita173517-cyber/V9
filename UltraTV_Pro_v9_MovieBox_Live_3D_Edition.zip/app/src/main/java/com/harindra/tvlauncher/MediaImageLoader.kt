package com.harindra.tvlauncher

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object MediaImageLoader {

    private var maxCacheKb = 8192
    private var cache: LruCache<String, Bitmap> = createCache(maxCacheKb)

    private val appExecutor = Executors.newFixedThreadPool(2)
    private val netExecutor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun initForDevice(context: Context) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mi)
        val totalMb = mi.totalMem / (1024L * 1024L)
        maxCacheKb = if (totalMb < 900L) 3584 else 12288
        cache = createCache(maxCacheKb)
    }

    private fun createCache(sizeKb: Int): LruCache<String, Bitmap> {
        return object : LruCache<String, Bitmap>(sizeKb) {
            override fun sizeOf(key: String, value: Bitmap): Int {
                return (value.byteCount / 1024).coerceAtLeast(1)
            }
        }
    }

    fun loadAppIcon(pm: PackageManager, packageName: String, target: ImageView) {
        val key = "pkg:$packageName"
        target.tag = key
        val cached = cache.get(key)
        if (cached != null && !cached.isRecycled) {
            target.setImageBitmap(cached)
            return
        }

        target.setImageResource(
            if (packageName == "com.harindra.iptvpro") R.drawable.ic_3d_iptv
            else R.drawable.ic_3d_apps
        )

        appExecutor.execute {
            val bmp = try {
                val drawable = pm.getApplicationBanner(packageName)
                    ?: pm.getApplicationIcon(packageName)
                drawableToScaledBitmap(drawable, 112)
            } catch (_: Throwable) {
                null
            }

            if (bmp != null) {
                cache.put(key, bmp)
                mainHandler.post {
                    if (target.tag == key && !bmp.isRecycled) {
                        target.setImageBitmap(bmp)
                    }
                }
            }
        }
    }

    fun loadRemoteImage(url: String, target: ImageView, fallbackResId: Int, targetWidthPx: Int = 440) {
        if (url.isBlank() || (!url.startsWith("http://") && !url.startsWith("https://"))) {
            target.tag = null
            target.setImageResource(fallbackResId)
            return
        }

        val key = "img:$url"
        target.tag = key
        val cached = cache.get(key)
        if (cached != null && !cached.isRecycled) {
            target.setImageBitmap(cached)
            return
        }

        target.setImageResource(fallbackResId)

        netExecutor.execute {
            val bmp = fetchBitmap(url, targetWidthPx)
            if (bmp != null) {
                cache.put(key, bmp)
                mainHandler.post {
                    if (target.tag == key && !bmp.isRecycled) {
                        target.alpha = 0.25f
                        target.setImageBitmap(bmp)
                        target.animate().alpha(1f).setDuration(220L).start()
                    }
                }
            }
        }
    }

    private fun fetchBitmap(url: String, maxDim: Int): Bitmap? {
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 4500
                readTimeout = 6000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android TV) UltraTVPro/6.0")
            }
            if (conn.responseCode in 200..299) {
                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            } else {
                conn.disconnect()
                null
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun trimMemory() {
        cache.evictAll()
    }

    private fun drawableToScaledBitmap(drawable: Drawable, targetH: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val src = drawable.bitmap
            if (src.width <= targetH * 2 && src.height <= targetH) return src
            val aspect = src.width.toFloat() / src.height.coerceAtLeast(1).toFloat()
            val outW = (targetH * aspect).toInt().coerceIn(targetH, targetH * 2)
            return Bitmap.createScaledBitmap(src, outW, targetH, true)
        }
        val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: targetH
        val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: targetH
        val aspect = w.toFloat() / h.coerceAtLeast(1).toFloat()
        val outW = (targetH * aspect).toInt().coerceIn(targetH, targetH * 2)
        val bitmap = Bitmap.createBitmap(outW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
