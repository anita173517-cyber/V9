package com.harindra.tvlauncher

import android.content.Context
import android.net.Uri

object ContinueWatchingEngine {

    private val WATCH_NEXT_URI = Uri.parse("content://android.media.tv/watch_next_program")

    fun buildContinueWatchingList(
        context: Context,
        prefs: PrefsManager,
        installedApps: List<AppItem>
    ): List<ContinueWatchingItem> {
        val result = mutableListOf<ContinueWatchingItem>()

        // 1. MovieBox Last Watched / Paused Movies & Series (High Priority!)
        val detectedMb = prefs.getDetectedMovieBoxMedia()
        if (detectedMb != null) {
            val (title, pkg, ts) = detectedMb
            result.add(
                ContinueWatchingItem(
                    id = "mb_det_${title.hashCode()}",
                    type = ContinueWatchingItem.TYPE_MOVIEBOX,
                    title = title,
                    subtitle = "Resume in MovieBox • Pick up where you left off",
                    sourceLabel = "🎬 MOVIEBOX LAST",
                    thumbUrl = "",
                    fallbackResId = R.drawable.hero_superhero_4k,
                    progressPercent = 62,
                    timestampMs = ts,
                    packageName = pkg
                )
            )
        }
        for (mb in prefs.getMovieBoxHistory().take(4)) {
            result.add(
                ContinueWatchingItem(
                    id = "mb_${mb.id}",
                    type = ContinueWatchingItem.TYPE_MOVIEBOX,
                    title = mb.title,
                    subtitle = "Resume in MovieBox • ${mb.meta}",
                    sourceLabel = "🎬 MOVIEBOX",
                    thumbUrl = mb.posterUrl,
                    fallbackResId = mb.posterResId,
                    progressPercent = 54,
                    timestampMs = mb.watchedAtMs,
                    deepLinkUri = mb.deepLinkUri
                )
            )
        }
        val mbApp = MovieBoxEngine.findMovieBoxPackage(installedApps)
        if (detectedMb == null && prefs.getMovieBoxHistory().isEmpty() && mbApp != null) {
            result.add(
                ContinueWatchingItem(
                    id = "mb_app_quick",
                    type = ContinueWatchingItem.TYPE_MOVIEBOX,
                    title = "${mbApp.label} — Resume Last Movie",
                    subtitle = "1-click continue watching in MovieBox",
                    sourceLabel = "🎬 MOVIEBOX",
                    thumbUrl = "",
                    fallbackResId = R.drawable.hero_superhero_4k,
                    progressPercent = 48,
                    timestampMs = System.currentTimeMillis(),
                    packageName = mbApp.packageName
                )
            )
        }

        // 2. RAM PLAYER IPTV Last Watched Channels
        val iptvHistory = prefs.getIptvHistory()
        for (ch in iptvHistory.take(4)) {
            result.add(
                ContinueWatchingItem(
                    id = "iptv_${ch.streamUrl.hashCode()}",
                    type = ContinueWatchingItem.TYPE_IPTV_CHANNEL,
                    title = ch.name,
                    subtitle = "Resume on RAM PLAYER IPTV • ${ch.group}",
                    sourceLabel = "📡 RAM PLAYER IPTV",
                    thumbUrl = ch.logoUrl,
                    fallbackResId = R.drawable.hero_sports_4k,
                    progressPercent = 76,
                    timestampMs = System.currentTimeMillis(),
                    streamUrl = ch.streamUrl,
                    streamUserAgent = ch.userAgent,
                    streamReferrer = ch.referrer,
                    packageName = prefs.preferredIptvPlayer.ifBlank { "com.harindra.iptvpro" }
                )
            )
        }
        val detectedIptv = prefs.getDetectedIptvMedia()
        if (detectedIptv != null) {
            val (title, pkg, ts) = detectedIptv
            result.add(
                ContinueWatchingItem(
                    id = "iptv_det_${title.hashCode()}",
                    type = ContinueWatchingItem.TYPE_IPTV_APP,
                    title = title,
                    subtitle = "Last watched in RAM PLAYER • Click to resume",
                    sourceLabel = "📡 RAM PLAYER LAST",
                    thumbUrl = "",
                    fallbackResId = R.drawable.hero_sports_4k,
                    progressPercent = 70,
                    timestampMs = ts,
                    packageName = pkg
                )
            )
        }
        val ramPlayerApp = installedApps.firstOrNull { it.packageName == "com.harindra.iptvpro" }
        if (iptvHistory.isEmpty() && detectedIptv == null && ramPlayerApp != null) {
            result.add(
                ContinueWatchingItem(
                    id = "iptv_app_resume",
                    type = ContinueWatchingItem.TYPE_IPTV_APP,
                    title = "${ramPlayerApp.label} — Resume Last Channel",
                    subtitle = "1-click open RAM PLAYER IPTV",
                    sourceLabel = "📡 RAM PLAYER IPTV",
                    thumbUrl = "",
                    fallbackResId = R.drawable.hero_sports_4k,
                    progressPercent = 65,
                    timestampMs = System.currentTimeMillis(),
                    packageName = ramPlayerApp.packageName
                )
            )
        }

        // 3. YouTube Last Watched Videos
        val detectedYt = prefs.getDetectedYouTubeMedia()
        if (detectedYt != null) {
            val (title, chName, ts) = detectedYt
            result.add(
                ContinueWatchingItem(
                    id = "yt_detected_${title.hashCode()}",
                    type = ContinueWatchingItem.TYPE_YOUTUBE_SEARCH,
                    title = title,
                    subtitle = "Last played on YouTube • $chName",
                    sourceLabel = "▶ YOUTUBE LAST",
                    thumbUrl = "",
                    fallbackResId = R.drawable.hero_action_4k,
                    progressPercent = 58,
                    timestampMs = ts
                )
            )
        }
        for (yt in prefs.getYouTubeHistory().take(4)) {
            result.add(
                ContinueWatchingItem(
                    id = "yt_${yt.videoId}",
                    type = ContinueWatchingItem.TYPE_YOUTUBE,
                    title = yt.title,
                    subtitle = "Continue on YouTube • ${yt.channelName}",
                    sourceLabel = "▶ YOUTUBE LAST",
                    thumbUrl = yt.thumbUrl,
                    fallbackResId = R.drawable.hero_scifi_4k,
                    progressPercent = 64,
                    timestampMs = yt.watchedAtMs,
                    videoId = yt.videoId
                )
            )
        }

        // 4. Native Android TV WatchNext Channel (MovieBox / YouTube / Netflix / Prime)
        result.addAll(queryAndroidTvWatchNext(context))

        return result.distinctBy { it.title.lowercase() }.take(14)
    }

    private fun queryAndroidTvWatchNext(context: Context): List<ContinueWatchingItem> {
        val list = mutableListOf<ContinueWatchingItem>()
        try {
            val projection = arrayOf(
                "_id", "title", "short_description", "poster_art_uri",
                "intent_uri", "package_name", "last_playback_position_millis", "duration_millis"
            )
            context.contentResolver.query(WATCH_NEXT_URI, projection, null, null, null)?.use { c ->
                val idxId = c.getColumnIndex("_id")
                val idxTitle = c.getColumnIndex("title")
                val idxDesc = c.getColumnIndex("short_description")
                val idxPoster = c.getColumnIndex("poster_art_uri")
                val idxIntent = c.getColumnIndex("intent_uri")
                val idxPkg = c.getColumnIndex("package_name")
                val idxPos = c.getColumnIndex("last_playback_position_millis")
                val idxDur = c.getColumnIndex("duration_millis")

                while (c.moveToNext() && list.size < 6) {
                    val title = if (idxTitle >= 0) c.getString(idxTitle).orEmpty() else ""
                    val intentUri = if (idxIntent >= 0) c.getString(idxIntent).orEmpty() else ""
                    if (title.isBlank() || intentUri.isBlank()) continue
                    val pkg = if (idxPkg >= 0) c.getString(idxPkg).orEmpty() else ""
                    val poster = if (idxPoster >= 0) c.getString(idxPoster).orEmpty() else ""
                    val desc = if (idxDesc >= 0) c.getString(idxDesc).orEmpty() else "Resume on TV"
                    val pos = if (idxPos >= 0) c.getLong(idxPos) else 0L
                    val dur = if (idxDur >= 0) c.getLong(idxDur) else 0L
                    val pct = if (dur > 0L) ((pos * 100L) / dur).toInt().coerceIn(8, 96) else 45
                    val badge = when {
                        pkg.contains("movie", true) || pkg.contains("mbox", true) -> "🎬 MOVIEBOX"
                        pkg.contains("youtube", true) -> "▶ YOUTUBE TV"
                        pkg.contains("iptv", true) || pkg.contains("harindra", true) -> "📡 RAM PLAYER"
                        else -> "📺 WATCH NEXT"
                    }
                    list.add(
                        ContinueWatchingItem(
                            id = "wn_${if (idxId >= 0) c.getLong(idxId) else title.hashCode()}",
                            type = ContinueWatchingItem.TYPE_WATCH_NEXT,
                            title = title,
                            subtitle = desc.ifBlank { "Click to resume immediately" },
                            sourceLabel = badge,
                            thumbUrl = poster,
                            fallbackResId = R.drawable.hero_fantasy_4k,
                            progressPercent = pct,
                            timestampMs = System.currentTimeMillis(),
                            packageName = pkg,
                            deepLinkUri = intentUri
                        )
                    )
                }
            }
        } catch (_: Throwable) { }
        return list
    }
}
