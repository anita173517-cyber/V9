package com.harindra.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class YouTubeAdapter(
    private val prefs: PrefsManager,
    private val onVideoClick: (YouTubeVideo) -> Unit
) : RecyclerView.Adapter<YouTubeAdapter.YtViewHolder>() {

    private val items = mutableListOf<YouTubeVideo>()

    fun submitList(newItems: List<YouTubeVideo>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): YtViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_youtube_card, parent, false)
        return YtViewHolder(view)
    }

    override fun onBindViewHolder(holder: YtViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class YtViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivThumb: ImageView = itemView.findViewById(R.id.ivYtThumb)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvYtTitle)
        private val tvChannel: TextView = itemView.findViewById(R.id.tvYtChannel)
        private val tvDuration: TextView = itemView.findViewById(R.id.tvYtDuration)

        fun bind(video: YouTubeVideo) {
            tvTitle.text = video.title
            tvChannel.text = video.channelName
            tvDuration.text = video.badge
            MediaImageLoader.loadRemoteImage(video.thumbUrl, ivThumb, video.fallbackResId, 440)

            itemView.setOnClickListener { onVideoClick(video) }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.10f)
            }
        }
    }
}
