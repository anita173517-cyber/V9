package com.harindra.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MovieBoxAdapter(
    private val prefs: PrefsManager,
    private val onClick: (MovieBoxItem) -> Unit
) : RecyclerView.Adapter<MovieBoxAdapter.MbHolder>() {

    private val items = mutableListOf<MovieBoxItem>()

    fun submitList(newItems: List<MovieBoxItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MbHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_moviebox_card, parent, false)
        return MbHolder(v)
    }

    override fun onBindViewHolder(holder: MbHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class MbHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivPoster: ImageView = itemView.findViewById(R.id.ivMbPoster)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvMbTitle)
        private val tvMeta: TextView = itemView.findViewById(R.id.tvMbMeta)
        private val tvRating: TextView = itemView.findViewById(R.id.tvMbRating)

        fun bind(item: MovieBoxItem) {
            tvTitle.text = item.title
            tvMeta.text = item.meta
            tvRating.text = item.rating
            if (item.posterUrl.isNotBlank()) {
                MediaImageLoader.loadRemoteImage(item.posterUrl, ivPoster, item.posterResId, 460)
            } else {
                ivPoster.setImageResource(item.posterResId)
            }
            itemView.setOnClickListener { onClick(item) }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.10f)
            }
        }
    }
}
